create procedure calculer_ligne_commande_montant_ht(IN p_id_devis int)
BEGIN

	UPDATE ligne_commande
	inner JOIN modele
	ON modele.id_modele = ligne_commande.modele_id
	and ligne_commande.devis_id = p_id_devis
	SET ligne_commande.montant_ht = ligne_commande.quantite * modele.prix_unitaire_ht;

END;

