create view v_devis as
select `TP_DEVIS`.`entreprise`.`raison_sociale`                                          AS `entreprise`,
       `TP_DEVIS`.`entreprise_contact`.`nom`                                             AS `entreprise_contact_nom`,
       `TP_DEVIS`.`devis`.`num_devis`                                                    AS `num_devis`,
       `TP_DEVIS`.`facture`.`total_ht`                                                   AS `total_ht`,
       `TP_DEVIS`.`facture`.`taux_tva_100`                                               AS `taux_tva_100`,
       (`TP_DEVIS`.`facture`.`total_ht` +
        ((`TP_DEVIS`.`facture`.`total_ht` * `TP_DEVIS`.`facture`.`taux_tva_100`) / 100)) AS `total_ttc`
from (((`TP_DEVIS`.`entreprise` join `TP_DEVIS`.`entreprise_contact` on ((
    `TP_DEVIS`.`entreprise_contact`.`entreprise_id` =
    `TP_DEVIS`.`entreprise`.`id_entreprise`))) join `TP_DEVIS`.`devis` on ((
    (`TP_DEVIS`.`devis`.`entreprise_id` = `TP_DEVIS`.`entreprise_contact`.`entreprise_id`) and
    (`TP_DEVIS`.`devis`.`entreprise_contact_id` = `TP_DEVIS`.`entreprise_contact`.`id_entreprise_contact`))))
       join `TP_DEVIS`.`facture` on ((`TP_DEVIS`.`facture`.`id_facture` = `TP_DEVIS`.`devis`.`facture_id`)));

