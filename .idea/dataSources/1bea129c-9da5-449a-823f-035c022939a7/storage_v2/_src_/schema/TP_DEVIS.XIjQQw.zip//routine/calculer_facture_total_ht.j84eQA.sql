create procedure calculer_facture_total_ht(IN p_id_devis int)
BEGIN
		
	call calculer_ligne_commande_montant_ht (p_id_devis);
	
	update facture
    inner join devis
    on devis.facture_id = facture.id_facture
	set facture.total_ht = 
	(
		select sum(ligne_commande.montant_ht)
		from ligne_commande
		inner join devis
		on devis.id_devis = ligne_commande.devis_id
		where  facture.id_facture = devis.facture_id
	) where devis.id_devis = p_id_devis;
    
END;

