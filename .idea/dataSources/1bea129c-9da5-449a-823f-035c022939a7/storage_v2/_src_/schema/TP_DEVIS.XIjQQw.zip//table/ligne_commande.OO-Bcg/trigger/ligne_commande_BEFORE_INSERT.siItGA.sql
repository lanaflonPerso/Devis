create trigger ligne_commande_BEFORE_INSERT
  before INSERT
  on ligne_commande
  for each row
BEGIN

	IF ( NEW.montant_ht IS NULL OR NEW.montant_ht = 0 ) THEN 

    SET NEW.montant_ht = NEW.quantite * 
    (
   		select modele.prix_unitaire_ht 
   		from modele  
   		where modele.id_modele = NEW.modele_id
   	);
    
    END IF;

END;

