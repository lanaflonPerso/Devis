create trigger entreprise_contact_BEFORE_INSERT
  before INSERT
  on entreprise_contact
  for each row
BEGIN 

	DECLARE num INTEGER; 
  
	IF ( NEW.id_entreprise_contact IS NULL OR NEW.id_entreprise_contact = 0 ) THEN 
		
		SET num =  
		( 
			SELECT COALESCE ( MAX( id_entreprise_contact ),  0 )  +  1 
			FROM entreprise_contact 
			WHERE entreprise_id = NEW.entreprise_id 
		); 

		SET NEW.id_entreprise_contact = num; 
	  
	END IF; 
  
  END;

